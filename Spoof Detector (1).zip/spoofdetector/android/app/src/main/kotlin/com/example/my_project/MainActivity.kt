package com.mycompany.spoofdetector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
