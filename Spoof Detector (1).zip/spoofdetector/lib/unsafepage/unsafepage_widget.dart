import '../flutter/flutter_theme.dart';
import '../flutter/flutter_util.dart';
import '../flutter/flutter_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class UnsafepageWidget extends StatefulWidget {
  const UnsafepageWidget({Key? key}) : super(key: key);

  @override
  _UnsafepageWidgetState createState() => _UnsafepageWidgetState();
}

class _UnsafepageWidgetState extends State<UnsafepageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterTheme.of(context).alternate,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 24),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.dangerous,
                      color: FlutterTheme.of(context).primaryBackground,
                      size: 150,
                    ),
                  ],
                ),
              ),
              Text(
                'OOPS!!!',
                style: FlutterTheme.of(context).title2.override(
                      fontFamily: 'Poppins',
                      color: FlutterTheme.of(context).primaryBtnText,
                      fontSize: 32,
                    ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
                child: Text(
                  '${FFAppState().currentnumber} is a ${FFAppState().currenttag}',
                  style: FlutterTheme.of(context).subtitle2.override(
                        fontFamily: 'Poppins',
                        color: FlutterTheme.of(context).primaryBtnText,
                        fontSize: 20,
                        fontWeight: FontWeight.w300,
                      ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                child: FFButtonWidget(
                  onPressed: () async {
                    context.pushNamed('Home');
                  },
                  text: 'Go Home',
                  options: FFButtonOptions(
                    width: 130,
                    height: 50,
                    color: FlutterTheme.of(context).primaryBtnText,
                    textStyle: FlutterTheme.of(context).subtitle2.override(
                          fontFamily: 'Poppins',
                          color: FlutterTheme.of(context).secondaryColor,
                        ),
                    elevation: 3,
                    borderSide: BorderSide(
                      color: Colors.transparent,
                      width: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
