import '../backend/backend.dart';
import '../flutter/flutter_theme.dart';
import '../flutter/flutter_util.dart';
import '../flutter/flutter_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class BufferpageCopyWidget extends StatefulWidget {
  const BufferpageCopyWidget({Key? key}) : super(key: key);

  @override
  _BufferpageCopyWidgetState createState() => _BufferpageCopyWidgetState();
}

class _BufferpageCopyWidgetState extends State<BufferpageCopyWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<TaggednumbersRecord>>(
      stream: queryTaggednumbersRecord(
        queryBuilder: (taggednumbersRecord) => taggednumbersRecord
            .where('phonenumber', isEqualTo: FFAppState().currentnumber),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                color: FlutterTheme.of(context).primaryColor,
              ),
            ),
          );
        }
        List<TaggednumbersRecord> bufferpageCopyTaggednumbersRecordList =
            snapshot.data!;
        final bufferpageCopyTaggednumbersRecord =
            bufferpageCopyTaggednumbersRecordList.isNotEmpty
                ? bufferpageCopyTaggednumbersRecordList.first
                : null;
        return Scaffold(
          key: scaffoldKey,
          backgroundColor: Color(0xFF5291E2),
          body: SafeArea(
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 24),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Lottie.network(
                          'https://i.pinimg.com/originals/48/6a/a0/486aa0fa1658b7522ecd8918908ece40.gif',
                          width: 200,
                          height: 200,
                          fit: BoxFit.cover,
                          frameRate: FrameRate(60),
                          repeat: false,
                          animate: true,
                        ),
                      ],
                    ),
                  ),
                  Text(
                    'Permission to Access Database',
                    style: FlutterTheme.of(context).title2.override(
                          fontFamily: 'Poppins',
                          color: FlutterTheme.of(context).primaryBtnText,
                          fontSize: 20,
                        ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        setState(() => FFAppState().currenttag =
                            bufferpageCopyTaggednumbersRecord!.tag!);
                      },
                      text: 'Access',
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).primaryBtnText,
                        textStyle: FlutterTheme.of(context)
                            .subtitle2
                            .override(
                              fontFamily: 'Poppins',
                              color:
                                  FlutterTheme.of(context).secondaryColor,
                            ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
                    child: Text(
                      FFAppState().currenttag,
                      style: FlutterTheme.of(context).subtitle2.override(
                            fontFamily: 'Poppins',
                            color: FlutterTheme.of(context).primaryBtnText,
                            fontSize: 20,
                            fontWeight: FontWeight.w300,
                          ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        if (FFAppState().currenttag == 'spoof') {
                          context.pushNamed('unsafepage');
                        } else {
                          context.pushNamed('Safepage');
                        }
                      },
                      text: 'Continue',
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).primaryBtnText,
                        textStyle: FlutterTheme.of(context)
                            .subtitle2
                            .override(
                              fontFamily: 'Poppins',
                              color:
                                  FlutterTheme.of(context).secondaryColor,
                            ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed('Home');
                      },
                      text: 'Home',
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).alternate,
                        textStyle:
                            FlutterTheme.of(context).subtitle2.override(
                                  fontFamily: 'Poppins',
                                  color: FlutterTheme.of(context)
                                      .primaryBackground,
                                ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
