import '../backend/backend.dart';
import '../flutter/flutter_theme.dart';
import '../flutter/flutter_util.dart';
import '../flutter/flutter_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BufferpageWidget extends StatefulWidget {
  const BufferpageWidget({Key? key}) : super(key: key);

  @override
  _BufferpageWidgetState createState() => _BufferpageWidgetState();
}

class _BufferpageWidgetState extends State<BufferpageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<TaggednumbersRecord>>(
      stream: queryTaggednumbersRecord(
        queryBuilder: (taggednumbersRecord) => taggednumbersRecord
            .where('phonenumber', isEqualTo: FFAppState().currentnumber),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                color: FlutterTheme.of(context).primaryColor,
              ),
            ),
          );
        }
        List<TaggednumbersRecord> bufferpageTaggednumbersRecordList =
            snapshot.data!;
        final bufferpageTaggednumbersRecord =
            bufferpageTaggednumbersRecordList.isNotEmpty
                ? bufferpageTaggednumbersRecordList.first
                : null;
        return Scaffold(
          key: scaffoldKey,
          backgroundColor: Color(0xFF5291E2),
          body: SafeArea(
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 24),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Icon(
                            Icons.cloud_done_outlined,
                            color:
                                FlutterTheme.of(context).primaryBackground,
                            size: 150,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    'Permission to Access Database',
                    style: FlutterTheme.of(context).title2.override(
                          fontFamily: 'Poppins',
                          color: FlutterTheme.of(context).primaryBtnText,
                          fontSize: 20,
                        ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        setState(() => FFAppState().currenttag =
                            bufferpageTaggednumbersRecord!.tag!);
                      },
                      text: 'Access',
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).primaryBtnText,
                        textStyle: FlutterTheme.of(context)
                            .subtitle2
                            .override(
                              fontFamily: 'Poppins',
                              color:
                                  FlutterTheme.of(context).secondaryColor,
                            ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
                    child: Text(
                      'Please click here once Done',
                      style: FlutterTheme.of(context).subtitle2.override(
                            fontFamily: 'Poppins',
                            color: FlutterTheme.of(context).primaryBtnText,
                            fontSize: 20,
                            fontWeight: FontWeight.w300,
                          ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        if (FFAppState().currenttag == 'spoof') {
                          context.pushNamed(
                            'unsafepage',
                            extra: <String, dynamic>{
                              kTransitionInfoKey: TransitionInfo(
                                hasTransition: true,
                                transitionType: PageTransitionType.scale,
                                alignment: Alignment.bottomCenter,
                              ),
                            },
                          );
                        } else {
                          context.pushNamed(
                            'Safepage',
                            extra: <String, dynamic>{
                              kTransitionInfoKey: TransitionInfo(
                                hasTransition: true,
                                transitionType: PageTransitionType.bottomToTop,
                              ),
                            },
                          );
                        }
                      },
                      text: 'Continue',
                      icon: Icon(
                        Icons.done_outlined,
                        size: 15,
                      ),
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).primaryBtnText,
                        textStyle: FlutterTheme.of(context)
                            .subtitle2
                            .override(
                              fontFamily: 'Poppins',
                              color:
                                  FlutterTheme.of(context).secondaryColor,
                              fontSize: 14,
                            ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 44, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed('Home');
                      },
                      text: 'Home',
                      options: FFButtonOptions(
                        width: 130,
                        height: 50,
                        color: FlutterTheme.of(context).alternate,
                        textStyle:
                            FlutterTheme.of(context).subtitle2.override(
                                  fontFamily: 'Poppins',
                                  color: FlutterTheme.of(context)
                                      .primaryBackground,
                                ),
                        elevation: 3,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
