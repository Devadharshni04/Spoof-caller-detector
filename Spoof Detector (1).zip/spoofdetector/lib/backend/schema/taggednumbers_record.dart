import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'taggednumbers_record.g.dart';

abstract class TaggednumbersRecord
    implements Built<TaggednumbersRecord, TaggednumbersRecordBuilder> {
  static Serializer<TaggednumbersRecord> get serializer =>
      _$taggednumbersRecordSerializer;

  String? get phonenumber;

  String? get tag;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(TaggednumbersRecordBuilder builder) => builder
    ..phonenumber = ''
    ..tag = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('taggednumbers');

  static Stream<TaggednumbersRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<TaggednumbersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s))!);

  TaggednumbersRecord._();
  factory TaggednumbersRecord(
          [void Function(TaggednumbersRecordBuilder) updates]) =
      _$TaggednumbersRecord;

  static TaggednumbersRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createTaggednumbersRecordData({
  String? phonenumber,
  String? tag,
}) {
  final firestoreData = serializers.toFirestore(
    TaggednumbersRecord.serializer,
    TaggednumbersRecord(
      (t) => t
        ..phonenumber = phonenumber
        ..tag = tag,
    ),
  );

  return firestoreData;
}
