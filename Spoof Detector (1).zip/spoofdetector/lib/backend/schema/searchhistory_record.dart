import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'searchhistory_record.g.dart';

abstract class SearchhistoryRecord
    implements Built<SearchhistoryRecord, SearchhistoryRecordBuilder> {
  static Serializer<SearchhistoryRecord> get serializer =>
      _$searchhistoryRecordSerializer;

  @BuiltValueField(wireName: 'Phonenumber')
  String? get phonenumber;

  DateTime? get timestamp;

  String? get tag;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(SearchhistoryRecordBuilder builder) => builder
    ..phonenumber = ''
    ..tag = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('searchhistory');

  static Stream<SearchhistoryRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<SearchhistoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s))!);

  SearchhistoryRecord._();
  factory SearchhistoryRecord(
          [void Function(SearchhistoryRecordBuilder) updates]) =
      _$SearchhistoryRecord;

  static SearchhistoryRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createSearchhistoryRecordData({
  String? phonenumber,
  DateTime? timestamp,
  String? tag,
}) {
  final firestoreData = serializers.toFirestore(
    SearchhistoryRecord.serializer,
    SearchhistoryRecord(
      (s) => s
        ..phonenumber = phonenumber
        ..timestamp = timestamp
        ..tag = tag,
    ),
  );

  return firestoreData;
}
