// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'searchhistory_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<SearchhistoryRecord> _$searchhistoryRecordSerializer =
    new _$SearchhistoryRecordSerializer();

class _$SearchhistoryRecordSerializer
    implements StructuredSerializer<SearchhistoryRecord> {
  @override
  final Iterable<Type> types = const [
    SearchhistoryRecord,
    _$SearchhistoryRecord
  ];
  @override
  final String wireName = 'SearchhistoryRecord';

  @override
  Iterable<Object?> serialize(
      Serializers serializers, SearchhistoryRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.phonenumber;
    if (value != null) {
      result
        ..add('Phonenumber')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.timestamp;
    if (value != null) {
      result
        ..add('timestamp')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.tag;
    if (value != null) {
      result
        ..add('tag')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  SearchhistoryRecord deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new SearchhistoryRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'Phonenumber':
          result.phonenumber = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'timestamp':
          result.timestamp = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'tag':
          result.tag = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$SearchhistoryRecord extends SearchhistoryRecord {
  @override
  final String? phonenumber;
  @override
  final DateTime? timestamp;
  @override
  final String? tag;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$SearchhistoryRecord(
          [void Function(SearchhistoryRecordBuilder)? updates]) =>
      (new SearchhistoryRecordBuilder()..update(updates))._build();

  _$SearchhistoryRecord._(
      {this.phonenumber, this.timestamp, this.tag, this.ffRef})
      : super._();

  @override
  SearchhistoryRecord rebuild(
          void Function(SearchhistoryRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  SearchhistoryRecordBuilder toBuilder() =>
      new SearchhistoryRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is SearchhistoryRecord &&
        phonenumber == other.phonenumber &&
        timestamp == other.timestamp &&
        tag == other.tag &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc($jc($jc(0, phonenumber.hashCode), timestamp.hashCode),
            tag.hashCode),
        ffRef.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'SearchhistoryRecord')
          ..add('phonenumber', phonenumber)
          ..add('timestamp', timestamp)
          ..add('tag', tag)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class SearchhistoryRecordBuilder
    implements Builder<SearchhistoryRecord, SearchhistoryRecordBuilder> {
  _$SearchhistoryRecord? _$v;

  String? _phonenumber;
  String? get phonenumber => _$this._phonenumber;
  set phonenumber(String? phonenumber) => _$this._phonenumber = phonenumber;

  DateTime? _timestamp;
  DateTime? get timestamp => _$this._timestamp;
  set timestamp(DateTime? timestamp) => _$this._timestamp = timestamp;

  String? _tag;
  String? get tag => _$this._tag;
  set tag(String? tag) => _$this._tag = tag;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  SearchhistoryRecordBuilder() {
    SearchhistoryRecord._initializeBuilder(this);
  }

  SearchhistoryRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _phonenumber = $v.phonenumber;
      _timestamp = $v.timestamp;
      _tag = $v.tag;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(SearchhistoryRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$SearchhistoryRecord;
  }

  @override
  void update(void Function(SearchhistoryRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  SearchhistoryRecord build() => _build();

  _$SearchhistoryRecord _build() {
    final _$result = _$v ??
        new _$SearchhistoryRecord._(
            phonenumber: phonenumber,
            timestamp: timestamp,
            tag: tag,
            ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,no_leading_underscores_for_local_identifiers,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new,unnecessary_lambdas
