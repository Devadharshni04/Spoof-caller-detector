package com.mycompany.spoofdetectoradmin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
