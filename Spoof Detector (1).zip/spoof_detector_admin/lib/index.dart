// Export pages
export 'signup/signup_widget.dart' show SignupWidget;
export 'login/login_widget.dart' show LoginWidget;
export 'home/home_widget.dart' show HomeWidget;
export 'addnum/addnum_widget.dart' show AddnumWidget;
